package com.StudentCurd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentCurdApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentCurdApplication.class, args);
	}

}
