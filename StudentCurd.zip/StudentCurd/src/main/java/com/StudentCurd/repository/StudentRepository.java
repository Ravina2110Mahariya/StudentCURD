package com.StudentCurd.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.StudentCurd.model.Student;


public interface StudentRepository extends JpaRepository <Student, Long> {

	
}
